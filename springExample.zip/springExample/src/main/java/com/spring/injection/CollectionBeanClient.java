package com.spring.injection;

import java.util.*;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class CollectionBeanClient {
	
	public static void main(String[] args) {
		AbstractApplicationContext factory = 
				new GenericXmlApplicationContext("applicationContext.xml");
	
	CollectionBean bean = (CollectionBean) factory.getBean("collectionBean");
	
	/* list 출력 
	List<String> group = bean.getAddressList();
	for( String address : group ) {
		System.out.println(address.toString());
	} 
	*/
	
	/* set 출력 
	Set<String> group = bean.getAddressList();
	Iterator<String> set = group.iterator();
	while(set.hasNext()) {
		System.out.println(set.next());
	}
	*/
	
	/* map 출력 
	Map<String,String> addressList = bean.getAddressList();
	for( Map.Entry<String, String>addList : addressList.entrySet() ) {
		String key = addList.getKey();
		String value = addList.getValue();
		System.out.println("key: "+key+", value: "+value);
	}
	*/
	
	/* properties 출력 */
	Properties addressList = bean.getAddressList();
	System.out.println(addressList.getProperty("홍길동"));
	System.out.println(addressList.getProperty("김철수"));
	

	factory.close();	
	}
}
