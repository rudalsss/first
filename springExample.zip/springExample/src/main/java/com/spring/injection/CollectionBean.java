package com.spring.injection;

import java.util.*;

public class CollectionBean {
	
	/* list 타입 
	private List<String> addressList;
	public List<String> getAddressList() { return addressList; }
	public void setAddressList(List<String> addressList) { this.addressList = addressList; }
	*/
	
	/* set 타입 : 중복값을 허용하지 않는 집합객체 
	private Set<String> addressList;
	public Set<String> getAddressList() { return addressList; }
	public void setAddressList(Set<String> addressList) { this.addressList = addressList; }
	*/
	
	/* map 타입 : key + value 
	private Map<String, String> addressList;
	public Map<String, String> getAddressList() { return addressList; }
	public void setAddressList(Map<String, String> addressList) { this.addressList = addressList; }
	*/
	
	/* properties 타입 */
	private Properties addressList;
	public Properties getAddressList() { return addressList; }
	public void setAddressList(Properties addressList) { this.addressList = addressList; }
	
}
