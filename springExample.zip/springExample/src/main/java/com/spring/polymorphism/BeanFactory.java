package com.spring.polymorphism;

//Factory 패턴 : 클라이언트에서 사용할 객체 생성을 캡슐화
public class BeanFactory {
	
	//getBean() : 매개변수로 받은 beanName에 해당하는 객체를 생성하여 리턴
	public Object getBean(String beanName) {
		if(beanName.equals("samsung")) {
			return new SamsungTV();
		} else if(beanName.equals("lg")) {
			return new LgTV();
		}
		return null;
	}
}
