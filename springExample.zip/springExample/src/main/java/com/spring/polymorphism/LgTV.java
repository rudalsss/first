package com.spring.polymorphism;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.Component;

import lombok.Setter;

@Component("tv")
public class LgTV implements TV {

	/* Speaker로 구현된 구현클래스가 하나 이상일 경우 
	@Autowired
	@Qualifier("apple")
	private Speaker speaker; */
	
	/* 1) 필드 객체에 의존성 주입
	@Autowired
	private Speaker speaker;*/
	
	/* 2) 생성자로 의존성 주입 
	private Speaker speaker;
	@Autowired
	public LgTV(Speaker spk) {
		this.speaker = spk;
	}*/
	
	/* 3) 설정자로 의존성 주입
	private Speaker speaker;
	public void setSpeaker(Speaker spk) {
		this.speaker = spk;
	}*/
	
	/* 3-1) lombok 설정자 생성하여 의존성 주입*/
	@Setter(onMethod_ = @Autowired)
	@Qualifier("apple")
	private Speaker speaker;
	
	
	
	public void turnOn() {
		System.out.println("LgTV --- 전원을 켠다.");
	}
	
	public void turnOff() {
		System.out.println("LgTV --- 전원을 끈다.");
	}
	
	public void soundUP() {
		System.out.println("LgTV --- 소리를 올린다.");
	}
	
	public void soundDown() {
		System.out.println("LgTV --- 소리를 내린다.");
	}
	
	
	
	public void powerOn() {
		System.out.println("LgTV --- 전원을 켠다.");
	}
	
	public void powerOff() {
		System.out.println("LgTV --- 전원을 끈다.");
	}
	
	public void volumeUp() {
		//System.out.println("LgTV --- 소리를 올린다.");
		speaker.volumeUp(); //@Component("sony") 호출
	}
	
	public void volumeDown() {
		//System.out.println("LgTV --- 소리를 내린다.");
		speaker.volumeDown(); //@Component("sony") 호출
	}
	
}
