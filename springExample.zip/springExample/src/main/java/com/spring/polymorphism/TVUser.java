package com.spring.polymorphism;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class TVUser {
	public static void main(String[] args) {
		
		//다형성 : 인터페이스타입 tv에 SamsungTV()를 참조시켰다.
		/*
		TV tv = new SamsungTV();
		tv.powerOn();
		tv.volumeUp();
		tv.volumeDown();
		tv.powerOff();
		*/
		
		//다형성 : 인터페이스타입 tv2에 LgTV()를 참조시켰다.
		/*
		TV tv2 = new LgTV();
		tv2.powerOn();
		tv2.volumeUp();
		tv2.volumeDown();
		tv2.powerOff();
		*/
		
		//디자인 패턴 : Run Contigurations로 실행
		/*
		BeanFactory factory = new BeanFactory();
		TV tv = (TV) factory.getBean(args[0]);
		// args[] : main메서드는 문자열을 매개변수로 받을 수 있다.
		tv.powerOn();
		tv.volumeUp();
		tv.volumeDown();
		tv.powerOff();
		*/
		
		//1. Spring 컨테이너를 구동한다
		AbstractApplicationContext factory = new GenericXmlApplicationContext("applicationContext.xml");
		//2. Spring 컨테이너로부터 필요한 객체를 요청(Lookup)한다.
		TV tv = (TV) factory.getBean("tv"); //id명으로 인스턴스를 넘겨받았다...
		tv.powerOn();
		tv.volumeUp();
		tv.volumeDown();
		tv.powerOff();
		//3. Spring 컨테이너를 종료한다
		factory.close();
	}	
}
