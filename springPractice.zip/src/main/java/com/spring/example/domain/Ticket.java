package com.spring.example.domain;

import lombok.Data;

@Data
public class Ticket {
	private int no;
	private String owner;
	private String grade;
}
