package com.spring.example.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
//import lombok.Getter;
import lombok.NoArgsConstructor;
//import lombok.Setter;
//import lombok.ToString;

//@Setter
//@Getter
//@ToString
@NoArgsConstructor
@AllArgsConstructor
@Data
public class SampleDTO {
	private String name;
	private int age;
	private String phone;
}
