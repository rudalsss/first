package com.spring.example.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.spring.example.domain.ExampleVO;
import com.spring.example.domain.SampleDTO;
import com.spring.example.domain.SampleDTOList;
import com.spring.example.domain.Ticket;

import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/sample/*") //모든 메서드매핑주소가 /sample/~~로 시작할 때 /**규칙일뿐, 폴더아님**/
@Log4j
public class SampleController {
	// 요청방법 : http://localhost:8080/sample/start :: 직접입력
	@RequestMapping( value="/start", method= { RequestMethod.GET, RequestMethod.POST } )
	public void basicGet() {
		log.info("/sample/start get........................");
		// "/sample/start" 추출 -> /WEB-INF/views/sample/start.jsp 로 완성 /**폴더아님**/
	}
	
	// 요청방법 : http://localhost:8080/sample/basic
	@RequestMapping( value="/basic", method= RequestMethod.GET )
	public String basicGet1() {
		log.info("/sample/start get........................");
		return "basic";
		// "basic" 추출 -> /WEB-INF/views/start.jsp 로 완성
	}
	
	// 요청방법 : http://localhost:8080/sample/exam01?name=홍길동&age=25
	//@RequestMapping( value="/exam01", method= RequestMethod.GET )
	@GetMapping("/exam01")
	public String exam01( @RequestParam("name") String name, @RequestParam("age") int age, Model model  ) {
		log.info("name: "+name);
		log.info("age: "+age);
		
		model.addAttribute("my_name", name);
		model.addAttribute("my_age", age);
		return "exam01"; // /WEB-INF/views/exam01.jsp
	}
	
	@RequestMapping("/test")
	public String test() {
		return "test"; // /WEB-INF/views/test.jsp
	}
	
	// 요청방법 : http://localhost:8080/sample/exam02?name=홍길동&age=25
	@GetMapping( "/exam02" )
	public String exam02(@ModelAttribute SampleDTO dto/* , Model model*/) {
		log.info("" + dto);  // dto.toSting()
		//model.addAttribute("dto", dto);
		return "exam02" ; // /WEB-INF/views/exam02.jsp
	}

	@GetMapping("/exam02List")
	public String exam02List(@RequestParam("language") ArrayList<String> lang, Model model) {
		log.info("language: "+lang.toString() );
		for(String s : lang ) {
			log.info("language values : "+s);
		}
		model.addAttribute("language", lang);
		return "exam02List";
	}

	/*	
	@GetMapping("/exam02List")
	public String exam02List( @ModelAttribute("language") ArrayList<String> language ) {
		log.info("language: "+ language.toString() );
		for(String s : language ) {
			log.info("language values : "+s );
		}
		return "exam02List";
	}
	*/
	
	@GetMapping("/exam02Array")
	public String exam02Array(@RequestParam("hobby") String[] hobby, Model model) {
		log.info("array hobby: " + Arrays.toString(hobby) );
		model.addAttribute("hobby", hobby);
		return "exam02Array";
	}

	/*
	@GetMapping("/exam02Array")
	public String exam02Array(@ModelAttribute("hobby") String[] my_hobby ) {
		log.info("array hobby: " + Arrays.toString(my_hobby) );
		return "exam02Array";
	}
	*/
	
	@GetMapping("/exam02Bean")
	public String exam02Bean(SampleDTOList list) {
		log.info("list dtolist: " + list );
		return "exam02Bean";
	}
	
	@GetMapping("/exam03")
	public String exam03(SampleDTO dto, @ModelAttribute("number") int number) {
		log.info("dto: " + dto );
		//log.info("number: " + number);
		return "sample/exam03";
	}
	
	/* @ResponseBody : 일반적인 JSP와 같은 뷰로 전달되는 게 아니라 데이터 자체를 전달하기 위한 용도*/
	/* @RestController( @Controller + @ResposeBody ): 모든 메서드의 반환타입이 jsp가 아니라 데이터인 컨트롤러  */
	@GetMapping(value="/getText", produces="text/plain; charset=utf-8")
	@ResponseBody //String을 produces에서 명시한 text data로 반환한다.
	public String getText() { 
		log.info("MIME TYPE: " + MediaType.TEXT_PLAIN_VALUE );
		return "안녕하세요"; 
		// /WEB-INF/views/안녕하세요.jsp (X)
		// string값을 text로 리턴
	}
	
	@GetMapping(value="/getExample", produces= MediaType.APPLICATION_XML_VALUE)
	@ResponseBody //SampleDTO를 produces에서 명시한 xml data로 반환한다.
	public SampleDTO getExample() {
		log.info("/getExample.....");
		SampleDTO dto = new SampleDTO();
		dto.setAge(10);
		dto.setName("홍길동");
		return dto; 
		// /WEB-INF/views/dto.jsp (X)
		// dto값을 xml형태로 리턴
	}
	
	@GetMapping(value="/getExample2", produces= MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody //ExampleVO를 produces에서 명시한 json data로 얻는다..
	public ExampleVO getExample2() {
		log.info("/getExample2.....");
		return new ExampleVO(1, "김철수", "010-5678-8013"); // ExampleVO의 all-args 생성자
		// ExampleVO값을 json형태로 리턴
	}
	
	/*
	@GetMapping("/getExample3")
	public ResponseEntity<String> getExample3() {
		log.info("/getExample3.....");
		//json데이터를 직접 생성
		String msg = "{ \"name\":\"홍길동\", \"email\":\"javauser@naver.com\" }";
		
		HttpHeaders header = new HttpHeaders();
		header.add("Content-Type", "application/json;charset=utf-8");
		return new ResponseEntity<>(msg, header, HttpStatus.OK);
	}
	*/
	
	@GetMapping("/getExample3")
	public ResponseEntity<ExampleVO> getExample3() {
		log.info("/getExample3.....");
		//json데이터를 직접 생성
		ExampleVO msg = new ExampleVO( 1, "홍길동", "javauser@naver.com" );
		
		HttpHeaders header = new HttpHeaders();
		header.add("Content-Type", "application/json;charset=utf-8");
		return new ResponseEntity<>(msg, header, HttpStatus.OK);
	}
	
	@GetMapping(value="/getList", produces=MediaType.APPLICATION_JSON_VALUE )
	@ResponseBody
	public List<ExampleVO> getList() {
		List<ExampleVO> list = new ArrayList<ExampleVO>();
		list.add(new ExampleVO(1, "홍길동", "010-6703-1209"));
		list.add(new ExampleVO(2, "한늘봄", "010-9427-8930"));
		list.add(new ExampleVO(3, "이진희", "010-1295-4510"));
		list.add(new ExampleVO(4, "박철희", "010-3492-6711"));
		return list;
	}
	//ExampleVO요소를 담은 list를 json형태로 리턴!!
	
	@GetMapping("/examMethod")
	public String examMethod() {
		log.info("/getMethod get.....");
		return "sample/examMethod";
	}
	
	@PostMapping( value="/examMethod", produces="text/plain;charset=utf-8")
	@ResponseBody
	public String examMethod(ExampleVO evo, Ticket tvo) { //param이 같은 이름의 필드에 대입
		log.info("/getMethod post.....");
		log.info("/ExmapleVO : "+evo+"Ticket: "+tvo);
		return "전송 성공!!";
	}
}
